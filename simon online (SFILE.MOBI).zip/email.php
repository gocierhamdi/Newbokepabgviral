<?php
$emailku = 'nafiswatsiq@gmail.com'; // masukin email lo disini kontol-_-
?>