<?php
//-----------Your Email
$admin  = "nafiswatsiq@gmail.com";
$result = "nafiswatsiq@gmail.com";

//-----------Your ADMINname
$name = "Admin";


//-----------Your Password
$pass_word = "admin12345";
?>