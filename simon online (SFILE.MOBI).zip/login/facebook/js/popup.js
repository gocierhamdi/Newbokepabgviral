// tombol untuk memunculkan popup
function login(){
	$('.login').show();
}
function info(){
	$('.info').show();
}
// tombol untuk menutup popup
function closelogin(){
	$(".login").hide()
}
function closeinfo(){
	$(".info").hide()
}